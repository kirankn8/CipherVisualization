/*         ______   ___    ___ 
 *        /\  _  \ /\_ \  /\_ \ 
 *        \ \ \L\ \\//\ \ \//\ \      __     __   _ __   ___ 
 *         \ \  __ \ \ \ \  \ \ \   /'__`\ /'_ `\/\`'__\/ __`\
 *          \ \ \/\ \ \_\ \_ \_\ \_/\  __//\ \L\ \ \ \//\ \L\ \
 *           \ \_\ \_\/\____\/\____\ \____\ \____ \ \_\\ \____/
 *            \/_/\/_/\/____/\/____/\/____/\/___L\ \/_/ \/___/
 *                                           /\____/
 *                                           \_/__/
 *
 *      Raspberry Pi-specific header defines.
 *
 *      See readme.txt for copyright information.
 */


#ifndef ALLEGRO_RASPBERRYPI
   #error bad include
#endif

#ifdef ALLEGRO_LIB_BUILD
#include "allegro5/platform/aintuthr.h"
#endif

/* Nothing left */
